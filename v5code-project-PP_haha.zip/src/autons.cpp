#include "vex.h"

void default_constants(){
  chassis.set_drive_constants(10, 1.5, 0, 10, 0);
  chassis.set_heading_constants(6, .4, 0, 1, 0);
  chassis.set_turn_constants(12, .4, .03, 3.5, 15);
  chassis.set_swing_constants(12, .3, .002, 1.6, 15);
  chassis.set_drive_exit_conditions(1.5, 300, 5000);
  chassis.set_turn_exit_conditions(1, 300, 3000);
  chassis.set_swing_exit_conditions(1, 300, 3000);
}

void odom_constants(){
  default_constants();
  chassis.drive_max_voltage = 8;
  chassis.drive_settle_error = 3;
}

void drive_test(){
  chassis.drive_distance(6);
  chassis.drive_distance(12);
  chassis.drive_distance(18);
  chassis.drive_distance(-36);
}

void turn_test(){
  chassis.turn_to_angle(5);
  chassis.turn_to_angle(45);
  chassis.turn_to_angle(90);
  chassis.turn_to_angle(225);
  chassis.turn_to_angle(0);
}

void swing_test(){
  chassis.left_swing_to_angle(90);
}

void full_test(){
  chassis.drive_distance(24);
  chassis.turn_to_angle(-45);
  chassis.drive_distance(-36);
  chassis.right_swing_to_angle(-90);
  chassis.drive_distance(24);
  chassis.turn_to_angle(0);
}

void prog()
{
  triport Piston1 = triport(vex::PORT22);
  digital_out Wings = digital_out(Piston1.A);
  //puts allience triball in goal
  chassis.turn_to_angle(40);
  chassis.drive_distance(5.5);
  chassis.right_swing_to_angle(0);
  chassis.left_swing_to_angle(90);
  Intake.spinFor(reverse, 360, degrees);
  chassis.drive_distance(-1.8);
  chassis.turn_to_angle(270);
  LeftMotors.spin(reverse, 100, percent);
  RightMotors.spin(reverse, 100, percent);
  wait(.5, sec);
  fullDrive.stop();
  //gets into cata shooting pos
  chassis.drive_distance(1);
  chassis.turn_to_angle(45);
  chassis.drive_distance(-4);
  chassis.turn_to_angle(157);
  chassis.drive_distance(-3.2);
  // Wings.set(!Wings.value());
  //cata shooting(shoots twice per revolution)
  // fullDrive.setStopping(hold);
  // Cata.setVelocity(60, percent);
  // for(int i = 0; i <= 2; i++)
  // {
  //   Cata.spinFor(forward, 360, degrees);
  // }
  // Cata.spinFor(forward, 90, degrees);
 
  //Drive to other side
  // Wings.set(!Wings.value());
  chassis.left_swing_to_angle(215);
  chassis.drive_distance(8.5);
  chassis.right_swing_to_angle(180);
  chassis.drive_distance(18);
  chassis.right_swing_to_angle(90);
  chassis.drive_distance(5);
  chassis.right_swing_to_angle(0);
  chassis.drive_distance(6);
  chassis.turn_to_angle(270);
  chassis.drive_distance(-8);
  chassis.turn_to_angle(0);
  // Wings.set(!Wings.value());//deployed
  fullDrive.spin(reverse, 100, percent);
  wait(.8, sec);
  fullDrive.stop();
  // Wings.set(!Wings.value());//undeployed
  chassis.turn_to_angle(0);
  chassis.drive_distance(8);
  chassis.turn_to_angle(270);
  chassis.drive_distance(-6);
  chassis.turn_to_angle(0);
  // Wings.set(!Wings.value());//deployed
  fullDrive.spin(reverse, 100, percent);
  wait(.8, sec);
  fullDrive.stop();
  // Wings.set(!Wings.value());//undeployed
  chassis.drive_distance(-2);
}

void Line()
{
  triport Piston1 = triport(vex::PORT22);
  digital_out Wings = digital_out(Piston1.A);
  chassis.turn_to_angle(-45);
  chassis.drive_distance(20);
  chassis.right_swing_to_angle(-90);
  Intake.spinFor(reverse, 2, seconds);
  chassis.turn_to_angle(90);
  chassis.drive_distance(-6);
  chassis.drive_distance(10);
  chassis.turn_to_angle(-150);
  Wings.set(!Wings.value());
  Cata.spinFor(12, seconds);
  Wings.set(!Wings.value());
  chassis.turn_to_angle(135);
  chassis.drive_distance(15);
  chassis.turn_to_angle(180);
  chassis.drive_distance(48);
  chassis.left_swing_to_angle(-90);
  chassis.drive_distance(22);
  chassis.drive_distance(-8);
  chassis.turn_to_angle(-15);
  chassis.drive_distance(32);
  chassis.turn_to_angle(90);
  Wings.set(!Wings.value());
  LeftMotors.setVelocity(50, percent);
  RightMotors.setVelocity(100, percent);
  chassis.drive_distance(-24);
  LeftMotors.setVelocity(100, percent);
  RightMotors.setVelocity(100, percent);
  chassis.drive_distance(22);
  chassis.turn_to_angle(90);
  LeftMotors.setVelocity(50, percent);
  RightMotors.setVelocity(100, percent);
  chassis.drive_distance(-24);
}

void noLine()
{
  triport Piston1 = triport(vex::PORT22);
  digital_out Wings = digital_out(Piston1.A);
  chassis.drive_distance(24);
  chassis.turn_to_angle(-45);
  chassis.drive_distance(20);
  chassis.right_swing_to_angle(-90);
  Intake.spinFor(reverse, 2, seconds);
  chassis.turn_to_angle(90);
  chassis.drive_distance(-6);
  chassis.drive_distance(10);
  chassis.turn_to_angle(-150);
  Wings.set(!Wings.value());
  Cata.spinFor(12, seconds);
  Wings.set(!Wings.value());
  chassis.turn_to_angle(135);
  chassis.drive_distance(15);
  chassis.turn_to_angle(180);
  chassis.drive_distance(48);
  chassis.left_swing_to_angle(-90);
  chassis.drive_distance(22);
  chassis.drive_distance(-8);
  chassis.turn_to_angle(-15);
  chassis.drive_distance(32);
  chassis.turn_to_angle(90);
  Wings.set(!Wings.value());
  LeftMotors.setVelocity(50, percent);
  RightMotors.setVelocity(100, percent);
  chassis.drive_distance(-24);
  LeftMotors.setVelocity(100, percent);
  RightMotors.setVelocity(100, percent);
  chassis.drive_distance(22);
  chassis.turn_to_angle(90);
  LeftMotors.setVelocity(50, percent);
  RightMotors.setVelocity(100, percent);
  chassis.drive_distance(-24);
}

void LineElim()
{
  triport Piston1 = triport(vex::PORT22);
  digital_out Wings = digital_out(Piston1.A);
  chassis.turn_to_angle(-45);
  chassis.drive_distance(20);
  chassis.right_swing_to_angle(-90);
  Intake.spinFor(reverse, 2, seconds);
  chassis.turn_to_angle(90);
  chassis.drive_distance(-6);
  chassis.drive_distance(10);
  chassis.turn_to_angle(-150);
  Wings.set(!Wings.value());
  Cata.spinFor(12, seconds);
  Wings.set(!Wings.value());
  chassis.turn_to_angle(135);
  chassis.drive_distance(15);
  chassis.turn_to_angle(180);
  chassis.drive_distance(48);
  chassis.left_swing_to_angle(-90);
  chassis.drive_distance(22);
  chassis.drive_distance(-8);
  chassis.turn_to_angle(-15);
  chassis.drive_distance(32);
  chassis.turn_to_angle(90);
  Wings.set(!Wings.value());
  LeftMotors.setVelocity(50, percent);
  RightMotors.setVelocity(100, percent);
  chassis.drive_distance(-24);
  LeftMotors.setVelocity(100, percent);
  RightMotors.setVelocity(100, percent);
  chassis.drive_distance(22);
  chassis.turn_to_angle(90);
  LeftMotors.setVelocity(50, percent);
  RightMotors.setVelocity(100, percent);
  chassis.drive_distance(-24);
}

void noLineElim()
{
  triport Piston1 = triport(vex::PORT22);
  digital_out Wings = digital_out(Piston1.A);
  chassis.drive_distance(24);
  chassis.turn_to_angle(-45);
  chassis.drive_distance(20);
  chassis.right_swing_to_angle(-90);
  Intake.spinFor(reverse, 2, seconds);
  chassis.turn_to_angle(90);
  chassis.drive_distance(-6);
  chassis.drive_distance(10);
  chassis.turn_to_angle(-150);
  Wings.set(!Wings.value());
  Cata.spinFor(12, seconds);
  Wings.set(!Wings.value());
  chassis.turn_to_angle(135);
  chassis.drive_distance(15);
  chassis.turn_to_angle(180);
  chassis.drive_distance(48);
  chassis.left_swing_to_angle(-90);
  chassis.drive_distance(22);
  chassis.drive_distance(-8);
  chassis.turn_to_angle(-15);
  chassis.drive_distance(32);
  chassis.turn_to_angle(90);
  Wings.set(!Wings.value());
  LeftMotors.setVelocity(50, percent);
  RightMotors.setVelocity(100, percent);
  chassis.drive_distance(-24);
  LeftMotors.setVelocity(100, percent);
  RightMotors.setVelocity(100, percent);
  chassis.drive_distance(22);
  chassis.turn_to_angle(90);
  LeftMotors.setVelocity(50, percent);
  RightMotors.setVelocity(100, percent);
  chassis.drive_distance(-24);
}