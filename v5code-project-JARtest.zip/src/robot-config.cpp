#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain Brain;

// VEXcode device constructors
controller Controller = controller(primary);
motor FrontLeft = motor(PORT11, ratio18_1, true);
motor MiddleLeft = motor(PORT13, ratio18_1, true);
motor BackLeft = motor(PORT12, ratio18_1, true);
motor FrontRight = motor(PORT18, ratio18_1, false);
motor MiddleRight = motor(PORT21, ratio18_1, false);
motor BackRight = motor(PORT19, ratio18_1, false);
motor Cata = motor(PORT15, ratio18_1, false);
motor Intake = motor(PORT16, ratio18_1, true);

inertial Inertial = inertial(PORT17);

rotation RotationSensor = rotation(PORT20, true);

motor_group LeftMotors = motor_group(FrontLeft, BackLeft, MiddleLeft);
motor_group RightMotors = motor_group(FrontRight, BackRight, MiddleRight);
motor_group fullDrive = motor_group(FrontLeft, BackLeft, MiddleLeft, FrontRight, BackRight, MiddleRight);
// VEXcode generated functions

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void) {
  // nothing to initialize
}